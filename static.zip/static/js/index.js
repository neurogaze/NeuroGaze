function displayPassage() {
    window.location.href = 'static/passage.html';
}

function displayImage() {
    window.location.href = 'static/images.html';
}

function redirectToRandomLetters() {
    window.location.href = 'static/randomLetters.html';
}